import greenfoot.*;

public class Blob extends Mover
{
    private int life = (Greenfoot.getRandomNumber(50) + 100);

    /**
     * Act - do whatever the Blob wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Blob()
    {
        GreenfootImage image = getImage();
        image.scale(30,30);
        setImage(image);
    }
    public void act() 
    {
        splatter();
        splatterMonster();
        splatterBoss();
        getZombie();
        getMonster();
        getBoss();
        move(15.0);
        life--;
        if (life == 0)
        {
            getWorld().addObject(new Splat(), getX(), getY());
            getWorld().removeObject(this);
        }    
    }

    public void getZombie() 
    {
        if (isTouching(Zombie.class))
        {
            removeTouching(Zombie.class);

            getWorld().addObject(new Zombie(), 
            Greenfoot.getRandomNumber(getWorld().getWidth()/2), 
            Greenfoot.getRandomNumber(getWorld().getHeight()));

        }
    }
    public void getMonster() 
    {
        if (isTouching(Monster.class))
        {
            removeTouching(Monster.class);

            getWorld().addObject(new Monster(), 
            Greenfoot.getRandomNumber(getWorld().getWidth()/2), 
            Greenfoot.getRandomNumber(getWorld().getHeight()));

        }
    }
    public void getBoss() 
    {
        if (isTouching(Boss.class))
        {
            removeTouching(Boss.class);

            getWorld().addObject(new Monster(), 
            Greenfoot.getRandomNumber(getWorld().getWidth()/2), 
            Greenfoot.getRandomNumber(getWorld().getHeight()));

        }
    }
    public void splatter()
    {
         if(isTouching(Zombie.class))
        {
            Splat splat = new Splat();
            getWorld().addObject(splat, getX(), getY());
        }
    }
    public void splatterMonster()
    {
         if(isTouching(Monster.class))
        {
            Splat splat = new Splat();
            getWorld().addObject(splat, getX(), getY());
        }
    }
    public void splatterBoss()
    {
         if(isTouching(Monster.class))
        {
            Splat splat = new Splat();
            getWorld().addObject(splat, getX(), getY());
        }
    }
}
