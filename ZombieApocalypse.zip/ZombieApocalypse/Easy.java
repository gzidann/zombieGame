import greenfoot.*;

/**
 * Write a description of class Sand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Easy extends World
{

    /**
     * Constructor for objects of class Sand.
     * 
     */
    public Easy()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(850, 480, 1, false); 

        prepare();

    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Cannon cannon = new Cannon();
        addObject(cannon, 20, 144);
        cannon.setRotation(180);
        cannon.setLocation(1073, 200);
        
        Zombie zombie = new Zombie();
        addObject(zombie, 50, 194);
        Zombie zombie2 = new Zombie();
        addObject(zombie2, 29, 300);

        
        cannon.setLocation(750, 217);
        cannon.setLocation(750, 245);
        
        //Greenfoot.playSound("zombie.mp3");
    }
    private int timer = 2*15*55; 
    public void act()
    {     
        if (--timer == 0){
            Greenfoot.stop();
            win w = new win();
            addObject(w,425, 240);
            
            Greenfoot.playSound("win.mp3");
        }   
    }
}
