import greenfoot.*;

/**
 * Write a description of class Sand here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Medium extends World
{

    /**
     * Constructor for objects of class Sand.
     * 
     */
    public Medium()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(850, 480, 1, false); 

        prepare();

    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Cannon cannon = new Cannon();
        addObject(cannon, 20, 144);
        cannon.setRotation(180);
        cannon.setLocation(1073, 200);
        
        Zombie zombie = new Zombie();
        addObject(zombie, 50, 194);
        Zombie zombie2 = new Zombie();
        addObject(zombie2, 29, 300);
        Zombie zombie3 = new Zombie();
        addObject(zombie3, 54, 420);
        Zombie zombie4 = new Zombie();
        addObject(zombie4, 24, 130);
       
        
        Monster monster = new Monster();
        addObject(monster, 1, 200);
        Monster monster2 = new Monster();
        addObject(monster2, 39, 200);
        
        cannon.setLocation(750, 217);
        cannon.setLocation(750, 245);
        
        //Greenfoot.playSound("zombie.mp3");
    }
    
    private int timer = 1*60*55; 
    public void act()
    {     
       //getWorld().showText("Time left: " + timer/55 + "seconds");
       //Greenfoot.showText("Time left: " + timer/(60*55) + " min. " + (timer%(60*55))/55 + "sec.");
        if (--timer == 0){
            Greenfoot.stop();
            win w = new win();
            addObject(w,425, 240);
            
            Greenfoot.playSound("win.mp3");
        }   
    }
}
