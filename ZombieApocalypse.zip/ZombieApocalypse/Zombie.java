import greenfoot.*;

public class Zombie extends Actor
{
    public Zombie()
    {
        GreenfootImage image = getImage();
        image.scale(100,100);
        setImage(image);
    }
    /**
     * Act - do whatever the Zombie wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Move();
        // Add your action code here.
    }    

    public void Move()
    {
        move(2);
     //   Greenfoot.playSound("zombie.mp3");
        if (isAtEdge()){
            Greenfoot.stop();
            gameover lose = new gameover();
            getWorld().addObject(lose,425,240);
            Greenfoot.playSound("zombie-eating.mp3");
            Greenfoot.playSound("gameover.mp3");
            
        }

    }
    
    public void splatter()
    {
        if(isAtEdge())
        {
            Splat splat = new Splat();
            getWorld().addObject(splat, getX(), getY());
        }
        
}
}