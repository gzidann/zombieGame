import greenfoot.*;

public class Splat extends Actor
{
    public Splat()
    {
        GreenfootImage image = getImage();
        image.scale(70,70);
        setImage(image);
    }
    /**
     * Act - do whatever the Splat wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        despawn();
    }
    private int life = 100;

    public void despawn()
    {
        life--;
        if (life == 0)
        {
            Splat splat = new Splat();
            getWorld().removeObject(this);
        }
    }
}
