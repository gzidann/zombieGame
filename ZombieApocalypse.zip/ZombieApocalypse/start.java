import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class start here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class start extends Actor
{
    public start()
    {
        GreenfootImage image = getImage();
        image.scale(150,150);
        setImage(image);
    }
    /**
     * Act - do whatever the start wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("space"))
        {
           Greenfoot.setWorld(new MenuLVL());
        }
    }    
}
