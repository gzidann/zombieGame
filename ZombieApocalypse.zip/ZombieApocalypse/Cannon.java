import greenfoot.*;
public class Cannon extends Actor
{
    public Cannon()
    {
        GreenfootImage image = getImage();
        image.scale(80,80);
        setImage(image);
    }
    /**
     * Act - do whatever the Cannon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.isKeyDown("s"))
        {
            setRotation (getRotation() - 5);
        }
        
        if (Greenfoot.isKeyDown("w"))
        {
            setRotation (getRotation() + 5);
        }
        
        if ("enter".equals(Greenfoot.getKey()))
        {
            fire();
        }
    }    
    private void fire()
    {
        Blob blob = new Blob();
        getWorld().addObject(blob, getX(), getY());
        blob.setRotation(getRotation());
        blob.move(30.0);
    }
      
}
