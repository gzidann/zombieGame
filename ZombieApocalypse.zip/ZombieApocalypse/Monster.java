import greenfoot.*;

public class Monster extends Actor
{
    public Monster()
    {
        GreenfootImage image = getImage();
        image.scale(110,110);
        setImage(image);
    }
    /**
     * Act - do whatever the Zombie wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Move();
        // Add your action code here.
    }    

    public void Move()
    {
        move(1);
        if (isAtEdge()){
            Greenfoot.stop();
            gameover lose = new gameover();
            getWorld().addObject(lose,425,240);
            Greenfoot.playSound("zombie-eating.mp3");
            Greenfoot.playSound("gameover.mp3");
        }

    }
    
    public void splatter()
    {
        if(isAtEdge())
        {
            Splat splat = new Splat();
            getWorld().addObject(splat, getX(), getY());
        }
        
}
}