import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

public class Mover extends Actor
{
    private static final double WALKING_SPEED = 3.0;
    
    /**
     * Turn 90 degrees to the right (clockwise).
     */
    public void turn()
    {
        turn(90);
    }
   
    public void turn(int angle)
    {
        setRotation(getRotation() + angle);
    }
   
    public void move()
    {
        move(WALKING_SPEED);
    }

    public void move(double distance)
    {
        double angle = Math.toRadians( getRotation() );
        int x = (int) Math.round(getX() + Math.cos(angle) * distance);
        int y = (int) Math.round(getY() + Math.sin(angle) * distance);
        
        setLocation(x, y);
    }

    public boolean atWorldEdge()
    {
        if(getX() < 20 || getX() > getWorld().getWidth() - 20)
            return true;
        if(getY() < 20 || getY() > getWorld().getHeight() - 20)
            return true;
        else
            return false;
    }
}